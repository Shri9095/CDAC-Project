import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Dashboard.css';
import './Resume.css'; // Ensure this file exists and is correctly referenced

function Dashboard() {
  const [activeSection, setActiveSection] = useState('profile');
  const [showWelcome, setShowWelcome] = useState(true); // Initialize to true to show welcome message
  const [formData, setFormData] = useState({
    // Profile fields
    profilePic: '',
    prn: '',
    name: '',
    course: '',
    bloodGroup: '',
    mobile: '',
    // Resume fields
    fullName: '',
    dateOfBirth: '',
    city: '',
    email: '',
    carrierObjective: '',
    sscCollegeName: '',
    sscMarks: '',
    sscPercentage: '',
    hscCollegeName: '',
    hscMarks: '',
    hscPercentage: '',
    experience: '',
    technicalSkills: '',
    hobbies: '',
    languagesKnown: '',
    declaration: '',
  });

  const [isEditingProfile, setIsEditingProfile] = useState(true); // Initially, allow editing
  const [isEditingResume, setIsEditingResume] = useState(true); // Initially, allow editing for resume
  const navigate = useNavigate();

  useEffect(() => {
    // Timer to hide the welcome message after 3 seconds
    const timer = setTimeout(() => {
      setShowWelcome(false);
    }, 3000); // 3000 milliseconds = 3 seconds

    return () => clearTimeout(timer); // Clean up the timer if the component unmounts
  }, []);

  const handleNavClick = (section) => {
    setActiveSection(section);
  };

  const handleLogout = () => {
    if (window.confirm("Thank you for using the system. Do you want to log out?")) {
      navigate('/');
    }
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));

    // Auto-calculate percentages
    if (name === 'sscMarks') {
      const sscPercentage = (value / 550) * 100;
      setFormData(prevData => ({ ...prevData, sscPercentage: sscPercentage.toFixed(2) }));
    }

    if (name === 'hscMarks') {
      const hscPercentage = (value / 650) * 100;
      setFormData(prevData => ({ ...prevData, hscPercentage: hscPercentage.toFixed(2) }));
    }
  };

  const handleProfileSubmit = (event) => {
    event.preventDefault();
    // Add your submit logic here, such as sending formData to a server
    console.log('Profile submitted:', formData);

    // Switch to display mode
    setIsEditingProfile(false);
  };

  const handleResumeSubmit = (event) => {
    event.preventDefault();
    // Add your submit logic here, such as sending formData to a server
    console.log('Resume submitted:', formData);

    // Switch to display mode
    setIsEditingResume(false);
  };

  const handleReset = () => {
    setFormData({
      // Reset profile fields
      profilePic: '',
      prn: '',
      name: '',
      course: '',
      bloodGroup: '',
      mobile: '',
      // Reset resume fields
      fullName: '',
      dateOfBirth: '',
      city: '',
      email: '',
      carrierObjective: '',
      sscCollegeName: '',
      sscMarks: '',
      sscPercentage: '',
      hscCollegeName: '',
      hscMarks: '',
      hscPercentage: '',
      experience: '',
      technicalSkills: '',
      hobbies: '',
      languagesKnown: '',
      declaration: '',
    });
  };

  const handleEditProfile = () => {
    setIsEditingProfile(true);
  };

  const handleEditResume = () => {
    setIsEditingResume(true);
  };

  return (
    <div className="dashboard-container">
      {showWelcome && (
        <div className="welcome-message">
          <h1>Welcome To Student Profile System Dashboard</h1>
        </div>
      )}
      <aside className={`sidebar ${showWelcome ? 'hidden' : ''}`}>
        <div className="profile-section">
          <img
            src="https://img.freepik.com/free-vector/mans-face-flat-style_90220-2877.jpg?size=626&ext=jpg"
            alt="Profile"
            className="profile-pic"
          />
        </div>
        <div className="section-menu">
          <ul>
            <li>
              <a href="#profile" onClick={() => handleNavClick('profile')}>
                Profile
              </a>
            </li>
            <li>
              <a href="#module-info" onClick={() => handleNavClick('module-info')}>
                Module Info
              </a>
            </li>
            <li>
              <a href="#timetable" onClick={() => handleNavClick('timetable')}>
                Timetable
              </a>
            </li>
            <li>
              <a href="#assignment" onClick={() => handleNavClick('assignment')}>
                Assignment
              </a>
            </li>
            <li>
              <a href="#feedback" onClick={() => handleNavClick('feedback')}>
                Feedback
              </a>
            </li>
            <li>
              <a href="#analytics" onClick={() => handleNavClick('analytics')}>
                Analytics
              </a>
            </li>
            <li>
              <a href="#resume" onClick={() => handleNavClick('resume')}>
                Resume
              </a>
            </li>
          </ul>
        </div>
        <button className="logout-button" onClick={handleLogout}>Logout</button>
      </aside>
      <main className={`main-content ${showWelcome ? 'hidden' : ''}`}>
        <div className="content-sections">
          <section id="profile" className={`section ${activeSection === 'profile' ? 'active' : ''}`}>
            <h2>Profile</h2>
            {isEditingProfile ? (
              <form className="profile-form" onSubmit={handleProfileSubmit}>
                <div className="form-group">
                  <label htmlFor="profilePic">Profile Picture URL:</label>
                  <input
                    id="profilePic"
                    name="profilePic"
                    type="text"
                    value={formData.profilePic}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="prn">PRN:</label>
                  <input
                    id="prn"
                    name="prn"
                    type="text"
                    value={formData.prn}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="name">Name:</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="course">Course:</label>
                  <input
                    id="course"
                    name="course"
                    type="text"
                    value={formData.course}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="bloodGroup">Blood Group:</label>
                  <input
                    id="bloodGroup"
                    name="bloodGroup"
                    type="text"
                    value={formData.bloodGroup}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="mobile">Mobile No.:</label>
                  <input
                    id="mobile"
                    name="mobile"
                    type="tel"
                    value={formData.mobile}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-buttons">
                  <button type="submit" className="submit-button">Submit</button>
                  <button type="button" className="reset-button" onClick={handleReset}>Reset</button>
                </div>
              </form>
            ) : (
              <div className="profile-info">
                <p><strong>Profile Picture URL:</strong> {formData.profilePic}</p>
                <p><strong>PRN:</strong> {formData.prn}</p>
                <p><strong>Name:</strong> {formData.name}</p>
                <p><strong>Course:</strong> {formData.course}</p>
                <p><strong>Blood Group:</strong> {formData.bloodGroup}</p>
                <p><strong>Mobile No.:</strong> {formData.mobile}</p>
                <button className="edit-button" onClick={handleEditProfile}>Edit Profile</button>
              </div>
            )}
          </section>

          {/* Other sections */}
          <section id="module-info" className={`section ${activeSection === 'module-info' ? 'active' : ''}`}>
            <h2>Module Info</h2>
            <div className="grid">
              <div className="card">
                <h3>Module 1</h3>
                <p>Details of Module 1</p>
              </div>
              <div className="card">
                <h3>Module 2</h3>
                <p>Details of Module 2</p>
              </div>
            </div>
          </section>

          <section id="timetable" className={`section ${activeSection === 'timetable' ? 'active' : ''}`}>
            <h2>Timetable</h2>
            <p>Your timetable goes here.</p>
          </section>

          <section id="assignment" className={`section ${activeSection === 'assignment' ? 'active' : ''}`}>
            <h2>Assignment</h2>
            <p>Your assignment details go here.</p>
          </section>

          <section id="feedback" className={`section ${activeSection === 'feedback' ? 'active' : ''}`}>
            <h2>Feedback</h2>
            <p>Provide your feedback here.</p>
          </section>

          <section id="analytics" className={`section ${activeSection === 'analytics' ? 'active' : ''}`}>
            <h2>Analytics</h2>
            <p>Analytics data goes here.</p>
          </section>

          <section id="resume" className={`section ${activeSection === 'resume' ? 'active' : ''}`}>
            <h2>Resume</h2>
            {isEditingResume ? (
              <form className="resume-form" onSubmit={handleResumeSubmit}>
                <div className="form-group">
                  <label htmlFor="fullName">Full Name:</label>
                  <input
                    id="fullName"
                    name="fullName"
                    type="text"
                    value={formData.fullName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="dateOfBirth">Date of Birth:</label>
                  <input
                    id="dateOfBirth"
                    name="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="city">City:</label>
                  <input
                    id="city"
                    name="city"
                    type="text"
                    value={formData.city}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="email">Email:</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="carrierObjective">Carrier Objective:</label>
                  <textarea
                    id="carrierObjective"
                    name="carrierObjective"
                    value={formData.carrierObjective}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="sscCollegeName">SSC College Name:</label>
                  <input
                    id="sscCollegeName"
                    name="sscCollegeName"
                    type="text"
                    value={formData.sscCollegeName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="sscMarks">SSC Marks:</label>
                  <input
                    id="sscMarks"
                    name="sscMarks"
                    type="number"
                    value={formData.sscMarks}
                    onChange={handleInputChange}
                  />
                  <p>Percentage: {formData.sscPercentage}%</p>
                </div>
                <div className="form-group">
                  <label htmlFor="hscCollegeName">HSC College Name:</label>
                  <input
                    id="hscCollegeName"
                    name="hscCollegeName"
                    type="text"
                    value={formData.hscCollegeName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="hscMarks">HSC Marks:</label>
                  <input
                    id="hscMarks"
                    name="hscMarks"
                    type="number"
                    value={formData.hscMarks}
                    onChange={handleInputChange}
                  />
                  <p>Percentage: {formData.hscPercentage}%</p>
                </div>
                <div className="form-group">
                  <label htmlFor="experience">Experience:</label>
                  <textarea
                    id="experience"
                    name="experience"
                    value={formData.experience}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="technicalSkills">Technical Skills:</label>
                  <textarea
                    id="technicalSkills"
                    name="technicalSkills"
                    value={formData.technicalSkills}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="hobbies">Hobbies:</label>
                  <textarea
                    id="hobbies"
                    name="hobbies"
                    value={formData.hobbies}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="languagesKnown">Languages Known:</label>
                  <textarea
                    id="languagesKnown"
                    name="languagesKnown"
                    value={formData.languagesKnown}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="declaration">Declaration:</label>
                  <textarea
                    id="declaration"
                    name="declaration"
                    value={formData.declaration}
                    onChange={handleInputChange}
                  />
                </div>
                <button type="submit" className="submit-button">Generate Resume</button>
              </form>
            ) : (
              <div className="resume-info">
                <p><strong>Full Name:</strong> {formData.fullName}</p>
                <p><strong>Date of Birth:</strong> {formData.dateOfBirth}</p>
                <p><strong>City:</strong> {formData.city}</p>
                <p><strong>Email:</strong> {formData.email}</p>
                <p><strong>Carrier Objective:</strong> {formData.carrierObjective}</p>
                <p><strong>SSC College Name:</strong> {formData.sscCollegeName}</p>
                <p><strong>SSC Marks:</strong> {formData.sscMarks} (Percentage: {formData.sscPercentage}%)</p>
                <p><strong>HSC College Name:</strong> {formData.hscCollegeName}</p>
                <p><strong>HSC Marks:</strong> {formData.hscMarks} (Percentage: {formData.hscPercentage}%)</p>
                <p><strong>Experience:</strong> {formData.experience}</p>
                <p><strong>Technical Skills:</strong> {formData.technicalSkills}</p>
                <p><strong>Hobbies:</strong> {formData.hobbies}</p>
                <p><strong>Languages Known:</strong> {formData.languagesKnown}</p>
                <p><strong>Declaration:</strong> {formData.declaration}</p>
                <button className="edit-button" onClick={handleEditResume}>Edit Resume</button>
              </div>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}

export default Dashboard;
